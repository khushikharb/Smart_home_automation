/***************************************************
   SMART HOME AUTOMATION PROJECT
   NodeMCU + 4-Channel Relay + 2 Manual Switch + Blynk App
***************************************************/

#define BLYNK_TEMPLATE_ID "TMPL38u3f25gF"
#define BLYNK_TEMPLATE_NAME "Smart Home Automation"
#define BLYNK_AUTH_TOKEN "zhrubIzcg-6eV8F50MGkP5Mn1Qbe4-WE"

#include <ESP8266WiFi.h>
#include <BlynkSimpleEsp8266.h>

// ----- WiFi Details -----
char auth[] = BLYNK_AUTH_TOKEN;
char ssid[] = "moto";       // apna wifi naam daal
char pass[] = "123456789";   // apna wifi password daal

// ----- Pin Setup -----
#define RELAY1 D1
#define RELAY2 D2
#define SWITCH1 D5
#define SWITCH2 D6

bool relay1State = LOW;
bool relay2State = LOW;

void setup() {
  Serial.begin(9600);
  Serial.println("Smart Home Automation Start...");

  pinMode(RELAY1, OUTPUT);
  pinMode(RELAY2, OUTPUT);
  pinMode(SWITCH1, INPUT_PULLUP);
  pinMode(SWITCH2, INPUT_PULLUP);

  digitalWrite(RELAY1, LOW);
  digitalWrite(RELAY2, LOW);

  Blynk.begin(auth, ssid, pass);
  Serial.println("WiFi Connecting...");
}

// ----- Blynk Buttons -----
BLYNK_WRITE(V1) {
  relay1State = param.asInt();
  digitalWrite(RELAY1, relay1State);
  Serial.print("Bulb 1 -> ");
  Serial.println(relay1State ? "ON" : "OFF");
}

BLYNK_WRITE(V2) {
  relay2State = param.asInt();
  digitalWrite(RELAY2, relay2State);
  Serial.print("Bulb 2 -> ");
  Serial.println(relay2State ? "ON" : "OFF");
}

void loop() {
  Blynk.run();
  manualControl();
}

// ----- Manual Switch Control -----
void manualControl() {
  static bool lastSwitch1 = HIGH;
  static bool lastSwitch2 = HIGH;

  bool currentSwitch1 = digitalRead(SWITCH1);
  bool currentSwitch2 = digitalRead(SWITCH2);

  // Switch 1 control
  if (lastSwitch1 == HIGH && currentSwitch1 == LOW) {
    relay1State = !relay1State;
    digitalWrite(RELAY1, relay1State);
    Blynk.virtualWrite(V1, relay1State);
    Serial.print("Manual Toggle -> Bulb 1 ");
    Serial.println(relay1State ? "ON" : "OFF");
    delay(300);
  }
  lastSwitch1 = currentSwitch1;

  // Switch 2 control
  if (lastSwitch2 == HIGH && currentSwitch2 == LOW) {
    relay2State = !relay2State;
    digitalWrite(RELAY2, relay2State);
    Blynk.virtualWrite(V2, relay2State);
    Serial.print("Manual Toggle -> Bulb 2 ");
    Serial.println(relay2State ? "ON" : "OFF");
    delay(300);
  }
  lastSwitch2 = currentSwitch2;
}
