// -------------------------------
// BLYNK CONFIGURATION
// -------------------------------
#define BLYNK_TEMPLATE_ID "TMPL38u3f25gF"
#define BLYNK_TEMPLATE_NAME "Smart Home Automation"
#define BLYNK_AUTH_TOKEN "zhrubIzcg-6eV8F50MGkP5Mn1Qbe4-WE"

#include <ESP8266WiFi.h>
#include <BlynkSimpleEsp8266.h>

char auth[] = BLYNK_AUTH_TOKEN;
char ssid[] = "realme narzo 30 5G";   // WiFi Name
char pass[] = "Anup@97090";           // WiFi Password

// -------------------------------
// PIN DEFINITIONS
// -------------------------------
#define relay1 D3       // Bedroom 1 bulb
#define relay2 D4       // Living room bulb
#define buzzer D2       // Entrance buzzer
#define pirSensor D1
#define trigPin D5
#define echoPin D6

// -------------------------------
// VARIABLES
// -------------------------------
long duration;
int distance;
BlynkTimer timer;

// Motion detection variables
unsigned long lastMotionTime = 0;
const unsigned long motionTimeout = 8000; // 8 seconds

// -------------------------------
// ULTRASONIC + PIR FUNCTION
// -------------------------------
void readSensors() {
  // --- Ultrasonic pulse generation ---
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  // --- Measure echo pulse duration ---
  duration = pulseIn(echoPin, HIGH);
  distance = duration * 0.034 / 2; // Convert to cm

  Serial.print("Distance: ");
  Serial.print(distance);
  Serial.println(" cm");

  // --- Ultrasonic buzzer logic ---
  if (distance > 0 && distance <= 20) {
    Serial.println("Object detected within 20cm → Beeping 3 times");
    for (int i = 0; i < 3; i++) {
      digitalWrite(buzzer, HIGH);
      delay(200);
      digitalWrite(buzzer, LOW);
      delay(200);
    }
    delay(1000); // small pause before next check
  }

  // --- PIR motion detection ---
  int motion = digitalRead(pirSensor);
  if (motion == HIGH) {
    digitalWrite(relay2, LOW); // Turn ON living room light
    lastMotionTime = millis();
    Serial.println("Motion detected: Living Room Bulb ON");
  } else {
    if (millis() - lastMotionTime > motionTimeout) {
      digitalWrite(relay2, HIGH); // Turn OFF light
      Serial.println("No motion: Living Room Bulb OFF");
    }
  }
}

// -------------------------------
// BLYNK BUTTON CONTROL FUNCTIONS
// -------------------------------
BLYNK_WRITE(V1) {
  int value = param.asInt();
  digitalWrite(relay1, value ? LOW : HIGH);
}

BLYNK_WRITE(V3) {
  int value = param.asInt();
  digitalWrite(buzzer, value ? HIGH : LOW);
}

BLYNK_WRITE(V4) {
  int value = param.asInt();
  digitalWrite(relay2, value ? LOW : HIGH);
}

// -------------------------------
// SETUP
// -------------------------------
void setup() {
  Serial.begin(9600);

  pinMode(relay1, OUTPUT);
  pinMode(relay2, OUTPUT);
  pinMode(buzzer, OUTPUT);
  pinMode(pirSensor, INPUT);
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);

  digitalWrite(relay1, HIGH);
  digitalWrite(relay2, HIGH);
  digitalWrite(buzzer, LOW);

  Serial.println("Smart Home + Ultrasonic + PIR System Started");

  Blynk.begin(auth, ssid, pass);
  timer.setInterval(1500L, readSensors); // Run every 1.5 seconds
}

// -------------------------------
// LOOP
// -------------------------------
void loop() {
  Blynk.run();
  timer.run();
}
